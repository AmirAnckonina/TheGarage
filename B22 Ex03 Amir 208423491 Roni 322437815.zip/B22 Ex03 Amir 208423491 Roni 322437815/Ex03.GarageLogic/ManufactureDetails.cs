﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex03.GarageLogic
{
    public class ManufactureDetails
    {
        private string m_LicenceID;
        private VehicleManufacturer.eVehicleType m_VehicleType;
        private string m_VehicleModelName;
        private string m_VehicleOwnerName;
        private string m_VehicleOwnerPhoneNumber;
        private Energy.eEnergyType m_EnergyType;
        private Car.eColor m_CarColor;
        private Car.eDoorsNumber m_DoorsNumberInCar;
        private Motorcycle.eMotorcycleLicenceType m_MotorcycleLicenceType;
        private int m_MotorcycleEngineCapacity;
        private bool m_HasCoolingCargo;
        private float m_CargoCapacity;
        private string m_WheelManufacturerName;

        public VehicleManufacturer.eVehicleType VehicleType
        {
            get
            {
                return m_VehicleType;
            }

            set
            {
                m_VehicleType = value;
            }
        }

        public string LicenceID
        {
            get
            {
                return m_LicenceID;
            }

            set
            {
                m_LicenceID = value;
            }
        }

        public string ModelName
        {
            get
            {
                return m_VehicleModelName;
            }

            set
            {
                m_VehicleModelName = value;
            }
        }

        public string VehicleOwnerName
        {
            get
            {
                return m_VehicleOwnerName;
            }

            set
            {
                m_VehicleOwnerName = value;
            }
        }

        public string VehicleOwnerPhoneNumber
        {
            get
            {
                return m_VehicleOwnerPhoneNumber;
            }

            set
            {
                m_VehicleOwnerPhoneNumber = value;
            }
        }

        public Energy.eEnergyType EnergyType
        {
            get
            {
                return m_EnergyType;
            }

            set
            {
                m_EnergyType = value;
            }
        }

        public Car.eColor CarColor
        {
            get
            {
                return m_CarColor;
            }

            set
            {
                m_CarColor = value;
            }
        }

        public Car.eDoorsNumber DoorsNumberInCar
        {
            get
            {
                return m_DoorsNumberInCar;
            }

            set
            {
                m_DoorsNumberInCar = value;
            }
        }

        public Motorcycle.eMotorcycleLicenceType MotorcycleLicenceType
        {
            get
            {
                return m_MotorcycleLicenceType;
            }

            set
            {
                m_MotorcycleLicenceType = value;
            }
        }

        public int MotorcycleEngineCapacity
        {
            get
            {
                return m_MotorcycleEngineCapacity;
            }

            set
            {
                m_MotorcycleEngineCapacity = value;
            }
        }

        public bool HasCoolingCargo
        {
            get
            {
                return m_HasCoolingCargo;
            }

            set
            {
                m_HasCoolingCargo = value;
            }
        }

        public float CargoCapacity
        {
            get
            {
                return m_CargoCapacity;
            }

            set
            {
                m_CargoCapacity = value;
            }
        }

        public string WheelManufacturerName
        {
            get
            {
                return m_WheelManufacturerName;
            }

            set
            {
                m_WheelManufacturerName = value;
            }
        }

        public void ClearForm()
        {
            m_VehicleType = VehicleManufacturer.eVehicleType.None;
            m_EnergyType = Energy.eEnergyType.None;
            m_CarColor = Car.eColor.None;
            m_DoorsNumberInCar = Car.eDoorsNumber.None;
            m_MotorcycleLicenceType = Motorcycle.eMotorcycleLicenceType.None;
            m_MotorcycleEngineCapacity = 0;
            m_HasCoolingCargo = false;
            m_CargoCapacity = 0;
        }
    }
}
