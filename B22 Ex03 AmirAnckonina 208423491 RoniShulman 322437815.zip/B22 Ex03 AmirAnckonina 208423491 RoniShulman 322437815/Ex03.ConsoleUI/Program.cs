﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ex03.ConsoleUI
{
    public class Program
    {
        public static void Main()
        {
            GarageManager garageManager = new GarageManager();
           
            garageManager.Run();
        }
    }
}
